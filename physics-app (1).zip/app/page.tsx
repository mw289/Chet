import { LandingPageContent } from "@/components/landing-page-content"

export default function LandingPage() {
  return <LandingPageContent />
}
